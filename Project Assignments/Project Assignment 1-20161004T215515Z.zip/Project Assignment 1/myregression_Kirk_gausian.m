function [ pred ] = myregression_Kirk_gausian( trainX,testX,noutput)
% X = [ones(length(trainX),1) trainX(:,1:size(trainX,2)-noutput)]; 
%     %testX]; 
%     %trainX(:,1:size(trainX,2)-noutput);];
% X = testX;
% t = trainX(:,size(trainX,2)-noutput+1:size(trainX,2));
% w = inv(X'*X)*X'*t
% %pred = [ones(length(testX),1) testX]*w;
% pred = X*w;
    
    X = (trainX(:,1:size(trainX,2)-noutput));
    
    
    t = trainX(:,size(trainX,2)-noutput+1:size(trainX,2));
    
    %with Scaling
    X = (X - mean(X))./sqrt(var(X));
    testX = (testX - mean(testX))./sqrt(var(X));

    
    
    
    
% for j = 1:size(trainX,2)-noutput
%     for i = 1:length(trainX)
%         trainX(i,j) = (trainX(i,j) - min(trainX(:,j)))/(max(trainX(:,j))-min(trainX(:,j)));
%     end
% end
% 
% for j = 1:size(testX,2)
%     for i = 1:length(testX)
%         testX(i,j) = (testX(i,j) - min(testX(:,j)))/(max(testX(:,j))-min(testX(:,j)));
%     end
% end
%     
    
    phi = exp((-(X - mean(X)).^2)./(2*var(X)));
    
    phi_test = exp((-(testX - mean(testX)).^2)./(2*var(testX)));
    
    w =phi\t;
    
    pred = phi_test*w;
% % Cross-Validation
% k = 3;
% min = intmax('int32');
% lambda =2;
% 
% for sections = 1:(floor(length(trainX)/k)):length(trainX)
%     CV_test_rows = sections : (sections + (floor(length(trainX))/k)-1);
%     CV_test = trainX(CV_test_rows, 1:size(trainX,2)-noutput);
%     CV_train_rows = setdiff((1:length(trainX)),CV_test_rows);
%     CV_train = trainX(CV_train_rows, :);
%     
% %     X = (CV_train(:,1:size(CV_train,2)-noutput));
%     x_phi = CV_train(:,1:size(CV_train,2)-noutput);
%     t = CV_train(:,size(CV_train,2)-noutput+1:size(CV_train,2));
%     min = intmax('int32');
%     
%     
% %     x_phi = [ones(length(x_phi),1) x_phi];
%     
%     
%     
% % Feature scaling for training data    
% % 
% %     x_phi_mean = repmat(mean(x_phi),length(x_phi),1);
% %     x_phi_var = repmat(sqrt(var(x_phi)),length(x_phi),1);
% %     CV_test_mean = repmat(mean(CV_test),length(CV_test),1);
% %     CV_test_var = repmat(sqrt(var(CV_test)),length(CV_test),1);
% %     
% %     x_phi = (x_phi-mean(x_phi))./sqrt(var(x_phi));
% %     CV_test = (CV_test - mean(CV_test))./sqrt(var(x_phi));
%     
% % Gausian basis function   
% %     phi = exp(-(x_phi - x_phi_mean).^2./(2*x_phi_var));
% %     phi_test = exp(-((CV_test - CV_test_mean).^2)./(2*(CV_test_var)));
%     
%     phi = exp((-(x_phi - mean(x_phi)).^2)./(2*var(x_phi)));
%     phi_test = exp((-(CV_test - mean(CV_test)).^2)./(2*var(CV_test)));
%     
%     
%     w = inv(phi'*phi)*(phi'*t);
% %     w = phi\t;
%     
%     CV_pred = phi_test*w;
% %     CV_pred = [ones(length(phi_test),1) phi_test]*w;
%     
%     
%     Y = trainX(CV_test_rows,6);
%     error = norm(CV_pred - Y);
%     
%     if min > error
%         CV_w = w;
%         min = error;
%     end
%     
% end
%     pred = testX*CV_w;
%     pred = [ones(length(testX),1) testX]*CV_w;
%     pred = testX*w;
      
    
end   



