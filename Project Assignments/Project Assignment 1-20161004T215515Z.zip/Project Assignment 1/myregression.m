function [ pred ] = myregression( trainX,testX,noutput)

% X = [ones(length(trainX),1) trainX(:,1:size(trainX,2)-noutput)]; 
%     %testX]; 
%     %trainX(:,1:size(trainX,2)-noutput);];
% X = testX;
% t = trainX(:,size(trainX,2)-noutput+1:size(trainX,2));
% w = inv(X'*X)*X'*t
% %pred = [ones(length(testX),1) testX]*w;
% pred = X*w;


% Cross-Validation

k = 3;
testFoldSize = floor(length(trainX)/k);
foldParts = 1:testFoldSize:length(trainX);
min = intmax('int32');
lambda =2;

for (fold = 1:k)
    testRows = foldParts(fold) : (foldParts(fold)+ testFoldSize-1);
    testCV = trainX(testRows, 1:size(trainX,2)-noutput);
    trainRows = setdiff((1:length(trainX)),testRows);
    trainCV = trainX(trainRows, :);
    
    X = (trainCV(:,1:size(trainCV,2)-noutput));
    X = (X-mean(X))./sqrt(var(X));
    X = [ones(length(X),1) X];
    % linear basis function
    phi = X;
    
%     Polynomial Basis funcion 
    p = 1;
    phi = X.^p;
    
    %Gaussian Basis Function
    
%     phi = exp(-((X-mean(X)).^2)/(2*(var(X))));
    %     Feature scaling
    %X = (X-mean(X))./sqrt(var(X));
% X =[ X  ];

%     phi = [ones(length(phi),1) phi];
    t = trainCV(:,size(trainCV,2)-noutput+1:size(trainCV,2));

    
    
%     w = inv(phi'*phi)*phi'*t;
%inv(A)*b can be slower and accurate so using X\t
   w = phi\t;          
%    w = (inv(lambda*eye(size(phi,2)) -(phi'*phi)))*phi'*t;
   

    
%     Feature scaling
    testCV = (testCV - mean(testCV))./sqrt(var(testCV));
    % testX = [testX   ];
    predCV = [ones(length(testCV),1) testCV]*w;
%     predCV = testCV*w;
predCV = real(predCV);
    
    Y = trainX(testRows,6);
    error = norm(predCV - Y);
    %+ ((lambda/2)*w);
    
    if min > error
        wCV = w;
%         lowestErrorFold = fold;
        min = error;
    end
end   

testX = (testX - mean(testX))./sqrt(var(testX));
pred = [ones(length(testX),1) testX]*wCV;
% pred = testX*wCV;
pred = real(pred);

end













