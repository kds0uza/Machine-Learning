function [ pred ] = myregression_Kirk_sigmoid( trainX,testX,noutput)
 
    X = (trainX(:,1:size(trainX,2)-noutput));
    
    
    t = trainX(:,size(trainX,2)-noutput+1:size(trainX,2));
    
%     X_mean = repmat(mean(X),length(X),1);
%     X_var = repmat(sqrt(var(X)),length(X),1);
%     testX_mean = repmat(mean(testX),length(testX),1);
%     testX_var = repmat(sqrt(var(testX)),length(testX),1);
    
    %with Scaling
%     X = (X - mean(X))./sqrt(var(X));
%     testX = (testX - mean(testX))./sqrt(var(X));
% 
%     
        
% for j = 1:size(trainX,2)-noutput
%     for i = 1:length(trainX)
%         trainX(i,j) = (trainX(i,j) - min(trainX(:,j)))/(max(trainX(:,j))-min(trainX(:,j)));
%     end
% end
% 
% for j = 1:size(testX,2)
%     for i = 1:length(testX)
%         testX(i,j) = (testX(i,j) - min(testX(:,j)))/(max(testX(:,j))-min(testX(:,j)));
%     end
% end
%    
    
    num = X - mean(X);
    den = sqrt(var(X));
    a = num/den;
    
    
    num_test = testX - mean(testX);
    den_test = sqrt(var(testX));
    b = num_test/den_test;
    
    phi = ones(size(a))./(ones(size(a)) + exp(-a));
    phi_test = ones(size(b))./(ones(size(b)) +exp(-b));

    w =phi\t;
    
    pred = phi_test*w;

    
end   



