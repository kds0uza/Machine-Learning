function [pred] = myregression2(trainX, testX, noutput)
%
% Function to perform regression analysis on a given data
%
% Outputs:
%        pred : gives predictens for the test data
%                size : ntext x noutput
%
% Inputs:
%        trainX: Training data ( ntrain x (nfeatures+noutput) )
%
%        testX : Testing data ( ntest x nfeatures )
%
%        noutput: Number of output columns
%
%
warning('off','all');
X = trainX(:,1:size(trainX,2)-noutput);
%X = (X-mean(X))./sqrt(var(X));

X =[ X  ];

X = [ones(length(X),1) X];
t = trainX(:,size(trainX,2)-noutput+1:size(trainX,2));

%w = inv(lambda*eye(size(X'*X))-X'*X)*X'*t;
w = X\t;


%testX = (testX - mean(testX))./sqrt(var(testX));
testX = [testX   ];
pred = [ones(length(testX),1) testX]*w;
pred = real(pred);

